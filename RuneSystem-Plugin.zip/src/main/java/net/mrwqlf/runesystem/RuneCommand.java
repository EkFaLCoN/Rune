package net.mrwqlf.runesystem;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class RuneCommand implements CommandExecutor, TabCompleter {

    private static final double KIRILMA_IHTIMALI = 0.40;
    private final Random random = new Random();

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            return handleRoll(sender);
        }

        switch (args[0].toLowerCase()) {
            case "ver" -> {
                return handleGive(sender, args);
            }
            case "tas" -> {
                return handleGiveStone(sender, args);
            }
            default -> {
                sendHelp(sender);
                return true;
            }
        }
    }

    /** Elindeki Rasgele Rün Taşı'nı kullanarak rün çekmeyi dener. */
    private boolean handleRoll(CommandSender sender) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(Component.text("Bu komutu sadece oyuncular kullanabilir.", NamedTextColor.RED));
            return true;
        }

        ItemStack hand = player.getInventory().getItemInMainHand();
        if (!RuneItems.isRandomStone(hand)) {
            sendHelp(player);
            return true;
        }

        hand.setAmount(hand.getAmount() - 1);
        player.getInventory().setItemInMainHand(hand);

        if (random.nextDouble() < KIRILMA_IHTIMALI) {
            player.sendMessage(Component.text("Rün Taşı kırıldı, hiçbir şey çıkmadı.", NamedTextColor.RED));
            player.playSound(player.getLocation(), Sound.BLOCK_GLASS_BREAK, 1f, 1f);
            return true;
        }

        RuneType[] all = RuneType.values();
        RuneType chosen = all[random.nextInt(all.length)];
        ItemStack rune = RuneItems.createRune(chosen);

        var leftover = player.getInventory().addItem(rune);
        leftover.values().forEach(item -> player.getWorld().dropItemNaturally(player.getLocation(), item));

        player.sendMessage(Component.text("Rün Taşı'ndan çıktı: ", NamedTextColor.GREEN)
                .append(Component.text(chosen.getDisplayName(), chosen.getCategory().getColor())));
        player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 1.4f);
        return true;
    }

    private boolean handleGive(CommandSender sender, String[] args) {
        if (!sender.hasPermission("runesystem.admin")) {
            sender.sendMessage(Component.text("Yetkin yok.", NamedTextColor.RED));
            return true;
        }
        if (args.length < 2) {
            sender.sendMessage(Component.text("Kullanım: /rune ver <rünAdı> [oyuncu]", NamedTextColor.RED));
            return true;
        }
        RuneType type;
        try {
            type = RuneType.valueOf(args[1].toUpperCase());
        } catch (IllegalArgumentException ex) {
            sender.sendMessage(Component.text("Geçersiz rün adı. Seçenekler: " + runeNames(), NamedTextColor.RED));
            return true;
        }
        Player target = resolveTarget(sender, args, 2);
        if (target == null) return true;
        target.getInventory().addItem(RuneItems.createRune(type));
        sender.sendMessage(Component.text(type.getDisplayName() + " verildi -> " + target.getName(), NamedTextColor.GREEN));
        return true;
    }

    private boolean handleGiveStone(CommandSender sender, String[] args) {
        if (!sender.hasPermission("runesystem.admin")) {
            sender.sendMessage(Component.text("Yetkin yok.", NamedTextColor.RED));
            return true;
        }
        Player target = resolveTarget(sender, args, 1);
        if (target == null) return true;
        target.getInventory().addItem(RuneItems.createRandomStone());
        sender.sendMessage(Component.text("Rasgele Rün Taşı verildi -> " + target.getName(), NamedTextColor.GREEN));
        return true;
    }

    private Player resolveTarget(CommandSender sender, String[] args, int index) {
        if (args.length > index) {
            Player p = sender.getServer().getPlayer(args[index]);
            if (p == null) {
                sender.sendMessage(Component.text("Oyuncu bulunamadı.", NamedTextColor.RED));
                return null;
            }
            return p;
        }
        if (sender instanceof Player p) return p;
        sender.sendMessage(Component.text("Konsoldan çağırırken oyuncu adı belirtmelisin.", NamedTextColor.RED));
        return null;
    }

    private void sendHelp(CommandSender sender) {
        sender.sendMessage(Component.text("--- Rün Sistemi ---", NamedTextColor.GOLD));
        sender.sendMessage(Component.text("Elinde Rasgele Rün Taşı varken /rune yaz -> rün çekmeyi dener (%40 kırılır).", NamedTextColor.YELLOW));
        if (sender.hasPermission("runesystem.admin")) {
            sender.sendMessage(Component.text("/rune ver <rün> [oyuncu] - rün ver", NamedTextColor.GRAY));
            sender.sendMessage(Component.text("/rune tas [oyuncu] - Rasgele Rün Taşı ver", NamedTextColor.GRAY));
        }
    }

    private String runeNames() {
        StringBuilder sb = new StringBuilder();
        for (RuneType t : RuneType.values()) sb.append(t.name()).append(" ");
        return sb.toString().trim();
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            return filter(List.of("ver", "tas"), args[0]);
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("ver")) {
            List<String> names = new ArrayList<>();
            for (RuneType t : RuneType.values()) names.add(t.name());
            return filter(names, args[1]);
        }
        if (args.length == 3 && args[0].equalsIgnoreCase("ver")) {
            return null; // oyuncu isimleri client tarafından tamamlanır
        }
        return List.of();
    }

    private List<String> filter(List<String> options, String prefix) {
        List<String> out = new ArrayList<>();
        for (String o : options) {
            if (o.toLowerCase().startsWith(prefix.toLowerCase())) out.add(o);
        }
        return out;
    }
}
