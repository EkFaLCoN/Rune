package net.mrwqlf.runesystem;

import net.kyori.adventure.text.Component;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.inventory.EquipmentSlotGroup;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Rün eşyaya basıldığında SADECE şunlar değişir: attribute_modifiers ve lore'un en altına
 * eklenen rün satırları. Eşyanın diğer verilerine (büyü, dayanıklılık, isim vs.) dokunulmaz.
 */
public class RuneDataManager {

    private final Plugin plugin;

    public RuneDataManager(Plugin plugin) {
        this.plugin = plugin;
    }

    public enum ApplyResult {
        OK,
        NOT_ELIGIBLE,   // bu eşya türüne hiç rün basılamaz
        WRONG_CATEGORY, // rün bu eşya kategorisine ait değil (örn. zırh rünü kılıca)
        MAX_REACHED     // eşyada zaten 3 rün var
    }

    /** Eşyanın hangi rün kategorisine ait olduğunu döndürür, uygun değilse null. */
    public RuneCategory categoryOf(Material material) {
        String n = material.name();

        if (n.endsWith("_SWORD") || n.endsWith("_AXE") || n.equals("TRIDENT")
                || n.equals("MACE") || n.equals("BOW") || n.equals("CROSSBOW")) {
            return RuneCategory.WEAPON;
        }
        if (n.endsWith("_HELMET") || n.endsWith("_CHESTPLATE")
                || n.endsWith("_LEGGINGS") || n.endsWith("_BOOTS")) {
            return RuneCategory.ARMOR;
        }
        if (n.endsWith("_PICKAXE") || n.endsWith("_SHOVEL") || n.endsWith("_HOE")) {
            return RuneCategory.TOOL;
        }
        return null;
    }

    public int appliedCount(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return 0;
        String raw = item.getItemMeta().getPersistentDataContainer()
                .get(RuneKeys.APPLIED_RUNES, PersistentDataType.STRING);
        if (raw == null || raw.isEmpty()) return 0;
        return raw.split(";").length;
    }

    public ApplyResult apply(ItemStack target, RuneType rune) {
        RuneCategory cat = categoryOf(target.getType());
        if (cat == null) return ApplyResult.NOT_ELIGIBLE;
        if (cat != rune.getCategory()) return ApplyResult.WRONG_CATEGORY;

        ItemMeta meta = target.getItemMeta();
        PersistentDataContainer pdc = meta.getPersistentDataContainer();

        String existingRaw = pdc.getOrDefault(RuneKeys.APPLIED_RUNES, PersistentDataType.STRING, "");
        List<String> runes = new ArrayList<>();
        if (!existingRaw.isEmpty()) {
            runes.addAll(Arrays.asList(existingRaw.split(";")));
        }
        if (runes.size() >= 3) return ApplyResult.MAX_REACHED;
        runes.add(rune.name());

        // --- Lore: sadece eskiden eklenmiş rün satırlarını çıkar, gerisine dokunma ---
        int oldCount = pdc.getOrDefault(RuneKeys.RUNE_LORE_COUNT, PersistentDataType.INTEGER, 0);
        List<Component> lore = meta.hasLore() ? new ArrayList<>(meta.lore()) : new ArrayList<>();
        for (int i = 0; i < oldCount && !lore.isEmpty(); i++) {
            lore.remove(lore.size() - 1);
        }

        // --- Attribute modifier'ları temizle (aynı kategori => aynı attribute) ---
        meta.removeAttributeModifier(rune.getAttribute());

        // --- Tüm güncel rünleri yeniden uygula ---
        EquipmentSlotGroup group = slotGroupFor(target.getType(), cat);
        for (int i = 0; i < runes.size(); i++) {
            RuneType rt = RuneType.valueOf(runes.get(i));
            lore.add(Component.text(rt.getDisplayName() + " " + rt.getCategory().getEmoji())
                    .color(rt.getCategory().getColor()));

            NamespacedKey slotKey = RuneKeys.slot(plugin, i);
            AttributeModifier modifier = new AttributeModifier(
                    slotKey, rt.getAmount(), AttributeModifier.Operation.ADD_NUMBER, group);
            meta.addAttributeModifier(rt.getAttribute(), modifier);
        }

        pdc.set(RuneKeys.APPLIED_RUNES, PersistentDataType.STRING, String.join(";", runes));
        pdc.set(RuneKeys.RUNE_LORE_COUNT, PersistentDataType.INTEGER, runes.size());
        meta.lore(lore);
        target.setItemMeta(meta);
        return ApplyResult.OK;
    }

    private EquipmentSlotGroup slotGroupFor(Material mat, RuneCategory cat) {
        if (cat == RuneCategory.ARMOR) {
            String n = mat.name();
            if (n.endsWith("_HELMET")) return EquipmentSlotGroup.HEAD;
            if (n.endsWith("_CHESTPLATE")) return EquipmentSlotGroup.CHEST;
            if (n.endsWith("_LEGGINGS")) return EquipmentSlotGroup.LEGS;
            return EquipmentSlotGroup.FEET;
        }
        // silah ve alet rünleri elde tutulunca etki etsin
        return EquipmentSlotGroup.MAINHAND;
    }
}
