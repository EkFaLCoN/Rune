package net.mrwqlf.runesystem;

import org.bukkit.plugin.java.JavaPlugin;

public class RuneSystemPlugin extends JavaPlugin {

    @Override
    public void onEnable() {
        RuneKeys.init(this);

        RuneDataManager runeDataManager = new RuneDataManager(this);

        getServer().getPluginManager().registerEvents(new SmithingListener(runeDataManager), this);

        RuneCommand runeCommand = new RuneCommand();
        var cmd = getCommand("rune");
        if (cmd != null) {
            cmd.setExecutor(runeCommand);
            cmd.setTabCompleter(runeCommand);
        }

        CraftRecipes.register(this);

        getLogger().info("RuneSystem etkinleştirildi.");
    }
}
