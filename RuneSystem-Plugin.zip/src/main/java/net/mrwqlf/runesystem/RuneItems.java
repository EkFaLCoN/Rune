package net.mrwqlf.runesystem;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.List;

public final class RuneItems {

    private RuneItems() {
    }

    public static ItemStack createRune(RuneType type) {
        ItemStack stack = new ItemStack(Material.PAPER);
        ItemMeta meta = stack.getItemMeta();

        meta.setItemModel(NamespacedKey.minecraft("item/runesystem/" + type.getModelKey()));
        meta.displayName(Component.text(type.getDisplayName(), type.getCategory().getColor())
                .decoration(TextDecoration.ITALIC, false));

        meta.lore(List.of(
                Component.text("Bir " + type.getCategory().getTurkce().toLowerCase() + " eşyasına", NamedTextColor.GRAY)
                        .decoration(TextDecoration.ITALIC, false),
                Component.text("demirci masasında basılır.", NamedTextColor.GRAY)
                        .decoration(TextDecoration.ITALIC, false),
                Component.text("En fazla 3 rün basılabilir.", NamedTextColor.DARK_GRAY)
                        .decoration(TextDecoration.ITALIC, false)
        ));

        meta.getPersistentDataContainer().set(RuneKeys.RUNE_TYPE, PersistentDataType.STRING, type.name());
        stack.setItemMeta(meta);
        return stack;
    }

    public static ItemStack createRandomStone() {
        ItemStack stack = new ItemStack(Material.PAPER);
        ItemMeta meta = stack.getItemMeta();

        meta.setItemModel(NamespacedKey.minecraft("item/runesystem/rasgele_run_tasi"));
        meta.displayName(Component.text("Rasgele Rün Taşı", NamedTextColor.LIGHT_PURPLE)
                .decoration(TextDecoration.ITALIC, false));

        meta.lore(List.of(
                Component.text("Elindeyken /rune yaz.", NamedTextColor.GRAY)
                        .decoration(TextDecoration.ITALIC, false),
                Component.text("%60 bir rün verir, %40 taş kırılır.", NamedTextColor.GRAY)
                        .decoration(TextDecoration.ITALIC, false)
        ));

        meta.getPersistentDataContainer().set(RuneKeys.RANDOM_STONE, PersistentDataType.BYTE, (byte) 1);
        stack.setItemMeta(meta);
        return stack;
    }

    public static boolean isRandomStone(ItemStack stack) {
        if (stack == null || !stack.hasItemMeta()) return false;
        Byte b = stack.getItemMeta().getPersistentDataContainer().get(RuneKeys.RANDOM_STONE, PersistentDataType.BYTE);
        return b != null && b == 1;
    }

    public static RuneType getRuneType(ItemStack stack) {
        if (stack == null || !stack.hasItemMeta()) return null;
        String id = stack.getItemMeta().getPersistentDataContainer().get(RuneKeys.RUNE_TYPE, PersistentDataType.STRING);
        if (id == null) return null;
        try {
            return RuneType.valueOf(id);
        } catch (IllegalArgumentException ex) {
            return null;
        }
    }
}
