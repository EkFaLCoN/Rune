package net.mrwqlf.runesystem;

import org.bukkit.attribute.Attribute;

public enum RuneType {

    HASAR_1(RuneCategory.WEAPON, "Hasar Rünü +0.5", Attribute.ATTACK_DAMAGE, 0.5, "hasar_1"),
    HASAR_2(RuneCategory.WEAPON, "Hasar Rünü +1", Attribute.ATTACK_DAMAGE, 1.0, "hasar_2"),

    ZIRH_1(RuneCategory.ARMOR, "Zırh Rünü +1 Koruma", Attribute.ARMOR, 1.0, "zirh_1"),
    ZIRH_2(RuneCategory.ARMOR, "Zırh Rünü +2 Koruma", Attribute.ARMOR, 2.0, "zirh_2"),

    // Alet rünleri (kendi tasarımım): kazı hızı attribute'una işleniyor
    ALET_1(RuneCategory.TOOL, "Alet Rünü +1 Kazı Hızı", Attribute.MINING_EFFICIENCY, 1.0, "alet_1"),
    ALET_2(RuneCategory.TOOL, "Alet Rünü +2 Kazı Hızı", Attribute.MINING_EFFICIENCY, 2.0, "alet_2");

    private final RuneCategory category;
    private final String displayName;
    private final Attribute attribute;
    private final double amount;
    private final String modelKey;

    RuneType(RuneCategory category, String displayName, Attribute attribute, double amount, String modelKey) {
        this.category = category;
        this.displayName = displayName;
        this.attribute = attribute;
        this.amount = amount;
        this.modelKey = modelKey;
    }

    public RuneCategory getCategory() {
        return category;
    }

    public String getDisplayName() {
        return displayName;
    }

    public Attribute getAttribute() {
        return attribute;
    }

    public double getAmount() {
        return amount;
    }

    public String getModelKey() {
        return modelKey;
    }
}
