package net.mrwqlf.runesystem;

import org.bukkit.NamespacedKey;
import org.bukkit.plugin.Plugin;

public final class RuneKeys {

    public static NamespacedKey RUNE_TYPE;        // rün item'ının üzerinde: hangi RuneType olduğu
    public static NamespacedKey RANDOM_STONE;     // Rasgele Rün Taşı işareti
    public static NamespacedKey APPLIED_RUNES;    // hedef eşyada: uygulanmış rünlerin listesi (";" ile ayrık)
    public static NamespacedKey RUNE_LORE_COUNT;  // hedef eşyada: kaç satır rün lore'u eklendiği

    private RuneKeys() {
    }

    public static void init(Plugin plugin) {
        RUNE_TYPE = new NamespacedKey(plugin, "rune_type");
        RANDOM_STONE = new NamespacedKey(plugin, "random_stone");
        APPLIED_RUNES = new NamespacedKey(plugin, "applied_runes");
        RUNE_LORE_COUNT = new NamespacedKey(plugin, "rune_lore_count");
    }

    public static NamespacedKey slot(Plugin plugin, int index) {
        return new NamespacedKey(plugin, "rune_slot_" + index);
    }
}
