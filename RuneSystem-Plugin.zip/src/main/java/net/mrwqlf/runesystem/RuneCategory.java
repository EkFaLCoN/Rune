package net.mrwqlf.runesystem;

import net.kyori.adventure.text.format.NamedTextColor;

public enum RuneCategory {
    WEAPON(NamedTextColor.RED, "Silah", "\u2694"),   // ⚔
    ARMOR(NamedTextColor.BLUE, "Zırh", "\uD83D\uDEE1"), // 🛡
    TOOL(NamedTextColor.GREEN, "Alet", "\u26CF");    // ⛏

    private final NamedTextColor color;
    private final String turkce;
    private final String emoji;

    RuneCategory(NamedTextColor color, String turkce, String emoji) {
        this.color = color;
        this.turkce = turkce;
        this.emoji = emoji;
    }

    public NamedTextColor getColor() {
        return color;
    }

    public String getTurkce() {
        return turkce;
    }

    public String getEmoji() {
        return emoji;
    }
}
