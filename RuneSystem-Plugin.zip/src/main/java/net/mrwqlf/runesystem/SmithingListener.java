package net.mrwqlf.runesystem;

import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.PrepareSmithingEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.SmithingInventory;

/**
 * Demirci masasında: şablon slotu = rün item'ı, taban slotu = savaş/zırh/alet eşyası,
 * ekleme slotu = 1 kuvars (bağlayıcı, kendi tasarımım). Üretilen sonuç, tabandaki eşyanın
 * BİREBİR KOPYASI + eklenen rün(ler) dışında hiçbir şeyi değişmemiş halidir — büyü,
 * dayanıklılık ve isim aynen korunur.
 */
public class SmithingListener implements Listener {

    private final RuneDataManager runeDataManager;

    public SmithingListener(RuneDataManager runeDataManager) {
        this.runeDataManager = runeDataManager;
    }

    @EventHandler
    public void onPrepareSmithing(PrepareSmithingEvent event) {
        SmithingInventory inv = event.getInventory();
        ItemStack template = inv.getInputTemplate();
        ItemStack base = inv.getInputEquipment();
        ItemStack addition = inv.getInputMineral();

        RuneType runeType = RuneItems.getRuneType(template);
        if (runeType == null || base == null || base.getType().isAir()) {
            event.setResult(null);
            return;
        }
        if (addition == null || addition.getType() != org.bukkit.Material.QUARTZ) {
            event.setResult(null);
            return;
        }

        ItemStack preview = base.clone();
        preview.setAmount(1);
        RuneDataManager.ApplyResult result = runeDataManager.apply(preview, runeType);

        if (result == RuneDataManager.ApplyResult.OK) {
            event.setResult(preview);
        } else {
            event.setResult(null);
        }
    }
}
