package net.mrwqlf.runesystem;

import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.RecipeChoice;
import org.bukkit.inventory.ShapelessRecipe;
import org.bukkit.inventory.SmithingTransformRecipe;
import org.bukkit.plugin.Plugin;

import java.util.ArrayList;
import java.util.List;

public final class CraftRecipes {

    private CraftRecipes() {
    }

    public static void register(Plugin plugin) {
        registerRuneStoneRecipe(plugin);
        registerSmithingRecipe(plugin);
    }

    /** Rasgele Rün Taşı kendi tasarımım olan basit bir tarifle üretilebiliyor. */
    private static void registerRuneStoneRecipe(Plugin plugin) {
        NamespacedKey key = new NamespacedKey(plugin, "rasgele_run_tasi");
        ItemStack result = RuneItems.createRandomStone();
        ShapelessRecipe recipe = new ShapelessRecipe(key, result);
        recipe.addIngredient(4, Material.AMETHYST_SHARD);
        recipe.addIngredient(1, Material.QUARTZ);
        plugin.getServer().addRecipe(recipe);
    }

    /**
     * Demirci masası tarifi: şablon = herhangi bir rün item'ı, taban = savaş/zırh/alet eşyası,
     * ekleme = 1 kuvars. Gerçek sonuç PrepareSmithingEvent içinde dinamik olarak hesaplanıp
     * event.setResult() ile üzerine yazılıyor; buradaki result sadece placeholder.
     */
    private static void registerSmithingRecipe(Plugin plugin) {
        NamespacedKey key = new NamespacedKey(plugin, "rune_apply");

        List<ItemStack> runeChoices = new ArrayList<>();
        for (RuneType type : RuneType.values()) {
            runeChoices.add(RuneItems.createRune(type));
        }
        RecipeChoice templateChoice = new RecipeChoice.ExactChoice(runeChoices);

        List<Material> eligible = new ArrayList<>();
        for (Material m : Material.values()) {
            String n = m.name();
            if (!m.isItem()) continue;
            if (n.endsWith("_SWORD") || n.endsWith("_AXE") || n.equals("TRIDENT") || n.equals("MACE")
                    || n.equals("BOW") || n.equals("CROSSBOW")
                    || n.endsWith("_HELMET") || n.endsWith("_CHESTPLATE") || n.endsWith("_LEGGINGS") || n.endsWith("_BOOTS")
                    || n.endsWith("_PICKAXE") || n.endsWith("_SHOVEL") || n.endsWith("_HOE")) {
                eligible.add(m);
            }
        }
        RecipeChoice baseChoice = new RecipeChoice.MaterialChoice(eligible);
        RecipeChoice additionChoice = new RecipeChoice.MaterialChoice(Material.QUARTZ);

        // Placeholder sonuç — gerçek sonuç SmithingListener tarafından ezilir.
        ItemStack placeholder = new ItemStack(Material.PAPER);

        SmithingTransformRecipe recipe = new SmithingTransformRecipe(
                key, placeholder, templateChoice, baseChoice, additionChoice);
        plugin.getServer().addRecipe(recipe);
    }
}
