# RuneSystem

Paper 26.2 için rün eklentisi. Rünler büyü değildir; eşyanın `attribute_modifiers`
verisine işlenir, diğer verilere (büyü, dayanıklılık, isim) dokunulmaz.

## Rünler
- **Hasar Rünü +0.5 / +1** (kırmızı, ⚔) — sadece silahlara (kılıç, balta, mızrak, gürz,
  yay, tatar yayı). Attribute: `attack_damage`.
- **Zırh Rünü +1 / +2 Koruma** (mavi, 🛡) — sadece zırh parçalarına. Attribute: `armor`.
- **Alet Rünü +1 / +2 Kazı Hızı** (yeşil, ⛏) — kendi eklediğim alet rünleri; kazma, kürek,
  çapa. Attribute: `mining_efficiency`.
- Bir eşyaya en fazla **3 rün** basılabilir.

## Rün elde etme
- **Rasgele Rün Taşı** yeni bir item (resourcepack'te mor sembollü taş).
  - Basit bir crafting tarifiyle üretilebiliyor: 4x Ametist Kıymığı + 1x Kuvars (kendi
    seçimim, istersen değiştiririm).
  - Elinde tutup `/rune` yazınca: %60 ihtimalle 6 rün türünden biri rastgele çıkar,
    %40 ihtimalle taş kırılır ve hiçbir şey vermez.
- `/rune ver <rünAdı> [oyuncu]` ve `/rune tas [oyuncu]` — admin (op) komutları, test/verme içindir.

## Rün basma (demirci masası)
- Şablon slotu: rün item'ı
- Taban slotu: uygun kategori eşya (silah/zırh/alet)
- Ekleme slotu: **1 Kuvars** (bağlayıcı — Minecraft'ın demirci masası 3 slotu da dolu
  istediği için ekledim, senin isteğinde belirtilmemişti; istersen başka bir madde ile
  değiştirebiliriz)
- Yanlış kategori (örn. zırh rünü kılıca) veya eşyada zaten 3 rün varsa sonuç çıkmaz.
- Sonradan büyü eklense bile (örs, kitap-örs) rün attribute'ları ve lore satırları silinmez;
  çünkü ayrı bileşenlerdir.

## Kurulum
1. Bu proje GitHub'a atılıp Actions ile derlenecek (bu ortamda javac/ağ yok, daha önceki
   projelerinde olduğu gibi). `.github/workflows/build.yml` zaten hazır — push edince
   `target/RuneSystem.jar` Actions sekmesinden inecek.
2. Jar'ı `plugins/` klasörüne at.
3. `RuneSystem-Resourcepack` klasöründeki `assets/minecraft/...` içeriğini kendi ana
   resourcepack'ine (`Created_By_MRWQLF`) birleştir — hiçbir mevcut dosyanın üzerine
   yazmıyor, sadece `items/item/runesystem/`, `models/item/runesystem/` ve
   `textures/item/runesystem/` altına yeni dosyalar ekliyor.

## Kendi tasarım kararlarım (onayına açık)
- Alet rünleri: kazı hızı (mining_efficiency) seçtim, istersen "Şans" (luck) gibi başka
  bir attribute'a çevirebilirim.
- Rasgele Rün Taşı'nın crafting tarifi ve demirci masasındaki "ekleme" maddesi (kuvars)
  benim seçimim — belirtmemiştin.
- Rün ikonları: attığın referans görselin stiline (gri taş tablet + renkli sembol)
  uygun olarak pixel-art üretildi (kılıç=silah, kalkan=zırh, kazma=alet, girdap=rasgele taş).
